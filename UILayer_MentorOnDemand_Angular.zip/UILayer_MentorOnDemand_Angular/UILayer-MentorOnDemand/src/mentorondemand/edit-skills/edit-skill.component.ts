import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edit-skill',
  templateUrl: './edit-skill.component.html',
  styleUrls: ['./edit-skill.component.css']
})
export class EditSkillComponent implements OnInit {

  ngOnInit(){}

}