import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'completed-training',
  templateUrl: './completed-training.component.html',
  styleUrls: ['./completed-training.component.css']
})
export class CompletedTrainingComponent implements OnInit {

  ngOnInit(){}

}