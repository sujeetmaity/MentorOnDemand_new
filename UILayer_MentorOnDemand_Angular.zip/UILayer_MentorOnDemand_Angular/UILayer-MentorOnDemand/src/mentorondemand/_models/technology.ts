export class Technology {
    id: string;
    name: string;
    mentorId: string;
    mentorName: string;
}
