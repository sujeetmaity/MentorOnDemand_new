import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  ngOnInit(){}

}